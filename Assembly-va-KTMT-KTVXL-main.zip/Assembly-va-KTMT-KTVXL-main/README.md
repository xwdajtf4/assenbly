# Assembly-va-Kien-Truc-May-Tinh
Đây là series cực kì hay tui làm dành cho các bạn đang muốn học Assembly thật nhanh và lý thuyết kiến trúc máy tính , kiến trúc vi xử lý . 
Thề asembly nó là ngôn ngữ máy nên mưới đầu học các bạn không hiểu cái gì mấy đâu nên hãy theo code của mình và học theo sẽ tốt hơn cho các bạn .
Các bạn down pdf về và thực hành theo mình .
Pdf là word convert sang nên copy được chỉ cần chạy +xem qua yt mình giải thích thì bạn sẽ hiểu nhanh thôi .
Tin tui không , tin thì theo , ko tin thì bỏ quá nhé .Huyinit

p/s : Nhưng mình khuyến khích bạn tự code lại để hiểu rõ hơn nhé . nếu thấy hay thì bấm star trên github ủng hộ mình nhé . iuuuu

p/s2: contact mình qua:

fb: https://www.facebook.com/huyinit13

Danh sách phát youtube bài giảng : https://www.youtube.com/watch?v=0v7FGPDWjR4&list=PLDYXQL9eThN7o1fsQIEn40eTiJCZTFVoc

youtube vlog :
https://www.youtube.com/channel/UCskOQJ8MIQXTAQ_jGryJNcQ

**1;** (asembly) Hiển thị lời chào Tiếng Anh và Tiếng Việt trên emu8086	8
**2:** (asembly) Nhập 1 ký tự và xuất ra màn hình trên emu8086	9
**3.** (asembly) nhập kí tự thường và chuyển sang kí tự hoa trên emu8086	11
**4.** (asembly) Nhập một chuỗi và in ra trên emu8086	12
**5.** (asembly) Nhập chuỗi thành chuỗi thường và chuỗi hoa trên emu8086	13
**6.** (asembly) IN CHUỖI ĐẢO NGƯỢC trên emu8086	15
**7.** (asembly) in chuỗi đảo ngược khi điền dấu # trên emu8086	16
**8**. (asembly)  Tìm giá trị lớn nhất của mảng	17
**9.** (asembly)  Nhập vào một số và tính giai thừa của số đó trên emu8086	20
**10**. (asembly)  Chuyển một số từ hệ 10 sang hệ 2 trên emu8086	21
**11.** (asembly)  Chuyển một số từ hệ 10 sang hệ 16 trên emu8086	23
**12**.TỔNG CÁC CHỮ SỐ	25
**13**.UCLN, BCNN:	27
**14**.tổng chia hết cho 7:	30
**15**.Tổng 2 số kiểu word	33
**16.** (asembly)  Đếm chiều dài 1 chuỗi trên emu8086	18
